//
//  AnimalListFavView.swift
//  MyAnimals
//
//  Created by Abdellah Skoundri on 15/01/2024.
//

import SwiftUI

struct AnimalListFavView: View {
    @ObservedObject var animal : Animal
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack {
                    ForEach(animals) { animal in
                            AnimalView(animal: animal)

                    }
                }
            }
        }
    }
}

#Preview {
    AnimalListFavView(animal: animalPreview)
}
